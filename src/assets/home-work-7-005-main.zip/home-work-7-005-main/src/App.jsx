import RouterMain from "./router"

function App() {
  return <RouterMain/>
}

export default App
