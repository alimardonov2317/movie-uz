import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <div className='h-screen'>
        <button className='px-14 py-6 flex m-0 mx-auto bg-indigo-600 text-white rounded'><Link to={"/admin/groups"}>Admin Panel</Link></button>
      </div>

    </>

  )
}

export default Home