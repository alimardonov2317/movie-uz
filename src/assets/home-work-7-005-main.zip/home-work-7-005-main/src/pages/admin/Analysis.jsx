import React from 'react'

const Analysis = () => {
  return (
    <div><img src="https://www.salesforce.com/blog/wp-content/uploads/sites/2/2024/03/Sales-Analysis.jpg" alt="" /></div>
  )
}

export default Analysis