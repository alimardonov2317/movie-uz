import React from 'react'

const Forms = () => {
  return (
    <div>
        <img src="https://ceblog.s3.amazonaws.com/wp-content/uploads/2017/09/19114623/forms.png" alt="" />
    </div>
  )
}

export default Forms