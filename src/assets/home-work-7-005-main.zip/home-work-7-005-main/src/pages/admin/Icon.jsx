import React from 'react'

const Icon = () => {
  return (
    <div>
        <img src="https://images.indianexpress.com/2023/12/Social-Media.jpg" alt="" />
    </div>
  )
}

export default Icon