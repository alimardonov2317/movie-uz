import React from 'react'

const Profile = () => {
  return (
    <div><img src="https://miro.medium.com/v2/resize:fit:1400/1*0iLRMzb8XMPjv7GuC4pyhQ.jpeg" alt="" /></div>
  )
}

export default Profile