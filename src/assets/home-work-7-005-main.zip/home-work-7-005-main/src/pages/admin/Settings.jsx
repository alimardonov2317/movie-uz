import React from 'react'

const Settings = () => {
  return (
    <div>
        <h1 className='text-3xl'>Settings</h1>

        <img src="https://images.squarespace-cdn.com/content/v1/5e949a92e17d55230cd1d44f/4b340b0d-98a8-4c93-8a83-51637a39227c/Settings1x1.png" alt="" />
    </div>
  )
}

export default Settings