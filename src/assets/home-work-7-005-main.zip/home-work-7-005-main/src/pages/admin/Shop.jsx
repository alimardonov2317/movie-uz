import React from 'react'

const Shop = () => {
  return (
    <div>
        <h1 className='text-3xl'>Shop</h1>
        <img src="https://cdn.pixabay.com/photo/2018/01/14/23/12/nature-3082832_960_720.jpg" alt="" />
    </div>
  )
}

export default Shop