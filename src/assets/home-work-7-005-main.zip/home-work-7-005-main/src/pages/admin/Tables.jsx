import React from 'react'

const Tables = () => {
  return (
    <div>
       <img src="https://i.ytimg.com/vi/d6PB-LfNOTM/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLDysR6fZbNHqoHtLHpDIuhrkZbPfw" alt="" />
    </div>
  )
}

export default Tables