import React, {useRef, useState} from 'react'
import { useCreateBlogMutation, useUpdateBlogMutation } from '../../redux/api/blog.api'
import { useNavigate } from 'react-router-dom'

const Users = () => {
  const navigate = useNavigate()
  const [createBlog, { isLoading: isCreateLoading }] = useCreateBlogMutation()
  const [updateBlog, {error}] = useUpdateBlogMutation()
  const [edit, setEdit] = useState(null)

  const title = useRef(null)
  const desc = useRef(null)
  const from = useRef(null)
  const type = useRef(null)
  const count = useRef(null)

  const handleCreateOrUpdateBlog = e => {
    e.preventDefault()
    let newBlog = {
      title: title.current.value,
      desc: desc.current.value,
      from: from.current.value,
      type: type.current.value,
      count: count.current.value,
    }
    if (edit) {
      updateBlog({ id: edit.id, body: newBlog })
        .unwrap()
        .then(() => {
          [title, desc, from, type, count].forEach(item => {
            item.current.value = ""
          })
          setEdit(null)
          navigate('/admin/groups/cars')
        })
    } else {
      createBlog(newBlog)
        .unwrap()
        .then(() => {
          title.current.value = ""
          desc.current.value = ""
          from.current.value = ""
          type.current.value = ""
          count.current.value = ""
          navigate('/admin/groups/cars')
        })
    }
  }

  const handleEdit = blog => {
    setEdit(blog)
    title.current.value = blog.title
    desc.current.value = blog.desc
    from.current.value = blog.from
    type.current.value = blog.type
    count.current.value = blog.count
  }

  return (
    <div className='flex container mx-auto gap-5 py-5'>
      <section className="max-w-[375px] w-full">
        <div className="w-full max-w-md p-8 space-y-8 rounded-lg shadow bg-gray-800">
          <h1 className="text-2xl font-bold leading-tight tracking-tight text-white">
            Create car
          </h1>
          <form onSubmit={handleCreateOrUpdateBlog} className="space-y-6">
            <div>
              <label htmlFor="BlogName" className="block mb-2 text-sm font-medium text-white">Car Name</label>
              <input type="text" ref={title} name="BlogName" className="block w-full p-2.5 border rounded-lg bg-gray-700 border-gray-600 placeholder-white text-white" placeholder="Car Name" required />
            </div>
            <div>
              <label htmlFor="description" className="block mb-2 text-sm font-medium text-white">Description</label>
              <input ref={desc} type="text" name="description" className="block w-full p-2.5 border rounded-lg bg-gray-700 border-gray-600 placeholder-white text-white" placeholder="Description" required />
            </div>
            <div>
              <label htmlFor="Author" className="block mb-2 text-sm font-medium text-white">From</label>
              <input ref={from} type="text" name="Author" className="block w-full p-2.5 border rounded-lg bg-gray-700 border-gray-600 placeholder-white text-white" placeholder="From" required />
            </div>
            <div>
              <label htmlFor="Type" className="block mb-2 text-sm font-medium text-white">Type</label>
              <input ref={type} type="text" name="Type" className="block w-full p-2.5 border rounded-lg bg-gray-700 border-gray-600 placeholder-white text-white" placeholder="Type" required />
            </div>
            <div>
              <label htmlFor="sold" className="block mb-2 text-sm font-medium text-white">Sold Count</label>
              <input ref={count} type="number" name="sold" className="block w-full p-2.5 border rounded-lg bg-gray-700 border-gray-600 placeholder-white text-white" placeholder="Sold Count" required />
            </div>
            <button type="submit" disabled={isCreateLoading} className="w-full py-2.5 px-5 text-sm font-medium text-white text-[20px] bg-emerald-400 rounded-lg hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 disabled:opacity-50 disabled:cursor-default cursor-pointer">{isCreateLoading ? "Loading" : edit ? "Save" : "Create"}</button>
          </form>
        </div>
      </section>
    </div>
  )
}

export default Users


