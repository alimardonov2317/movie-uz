import React from 'react'

const Widgets = () => {
  return (
    <div>
      <img src="https://macrofactorapp.com/wp-content/uploads/2023/10/image4.png" alt="" />
    </div>
  )
}

export default Widgets