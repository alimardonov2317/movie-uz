import React from 'react'
import { useGetBlogsQuery, useDeleteBlogMutation } from '../../../redux/api/blog.api'

const BlogList = () => {
  const { data, isLoading } = useGetBlogsQuery()
  const [deleteBlog] = useDeleteBlogMutation()

  const handleDeleteBlog = id => {
    deleteBlog(id)
  }

  return (
    <div className='container mx-auto'>
      {isLoading && <div className='text-center text-3xl'>Loading....</div>}
      <div className='grid grid-cols-4 gap-4 w-full h-fit'>
        {data?.map(blog => (
          <div className='shadow bg-gray-800 text-white p-4 rounded max-h-[900px] h-full max-w-[400px] w-full' key={blog.id}>
            <h3 className='text-xl font-bold pb-3 mb-1 border-gray-200 text-center'>{blog.title}</h3>
            <p>{blog.desc}</p>
            <p>{blog.from}</p>
            <p>{blog.type}</p>
            <p className='mb-2'>Sold Count: {blog.count}</p>
            <button onClick={() => handleDeleteBlog(blog.id)} className="py-1 px-5 bg-red-600 rounded cursor-pointer">Delete</button>
          </div>
        ))}
      </div>
    </div>
  )
}

export default BlogList

