import { mainApi } from './index'

const extendedApi = mainApi.injectEndpoints({
  endpoints: (build) => ({
    getBlogs: build.query({
      query: (params) => ({
        url:'/cars',
        method:"GET",
        params
      }),
      providesTags: ["CARS"]
    }),
    getSingleBlog: build.query({
      query: (id)=> ({
        url: `/cars/${id}`,
        method:"GET"
      }),
      providesTags: ["CARS"]
    }),
    createBlog: build.mutation({
      query: (body)=> ({
        url:"/cars",
        method: "POST",
        body
      }),
      invalidatesTags: ["CARS"]
    }),
    deleteBlog: build.mutation({
      query: (id)=> ({
        url: `/cars/${id}`,
        method: "DELETE"
      }),
      invalidatesTags: ["CARS"]
    }),
    updateBlog: build.mutation({
      query: ({id, body})=> ({
        url: `/cars/${id}`,
        method:"PUT",
        body
      }),
      invalidatesTags: ["CARS"]
    })
  }),
  overrideExisting: false,
})

export const { useGetBlogsQuery, useCreateBlogMutation, useDeleteBlogMutation, useUpdateBlogMutation, useGetSingleBlogQuery } = extendedApi