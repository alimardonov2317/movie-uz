import React, { lazy } from 'react'
import { Route, Routes } from 'react-router-dom'
import { SuspenseContainer } from '../utils'
import Apps from '../pages/admin/Icon'
const Home = lazy(() => import("../pages/Home"))
const About = lazy(() => import("../pages/About"))
const Contact = lazy(() => import("../pages/Contact"))
const Layout = lazy(() => import("../pages/Layout"))
const Admin = lazy(() => import("../pages/admin/Admin"))
const Groups = lazy(() => import("../pages/admin/Groups"))
const Users = lazy(() => import("../pages/admin/Users"))
const Shop = lazy(() => import("../pages/admin/Shop"))
const Text = lazy(() => import("../pages/admin/groups/Text"))
const Table = lazy(() => import("../pages/admin/groups/Table"))
const BlogList = lazy(() => import("../pages/admin/groups/BlogList"))
const Settings = lazy(() => import("../pages/admin/Settings"))
const Icon = lazy(() => import("../pages/admin/Icon"))
const Widgets = lazy(() => import("../pages/admin/Widgets"))
const Analysis = lazy(() => import("../pages/admin/Analysis"))
const Tables = lazy(() => import("../pages/admin/Tables"))
const Forms = lazy(() => import("../pages/admin/Forms"))
const Profile = lazy(() => import("../pages/admin/Profile"))

const RouterMain = () => {
  return (
    <Routes>
      <Route path='/' element={<SuspenseContainer><Layout /></SuspenseContainer>}>
        <Route path='/' element={<SuspenseContainer><Home /></SuspenseContainer>} />
        <Route path='about' element={<SuspenseContainer><About /></SuspenseContainer>} />
        <Route path='contact' element={<SuspenseContainer><Contact /></SuspenseContainer>} />
      </Route>
      <Route path='admin' element={<SuspenseContainer><Admin /></SuspenseContainer>}>
        <Route path='groups' element={<SuspenseContainer><Groups /></SuspenseContainer>}>
          <Route path='cars' element={<SuspenseContainer><BlogList /></SuspenseContainer>} />
          <Route path='table' element={<SuspenseContainer><Table /></SuspenseContainer>} />
          <Route path='text' element={<SuspenseContainer><Text /></SuspenseContainer>} />
        </Route>
        <Route path='users' element={<SuspenseContainer><Users /></SuspenseContainer>} />
        <Route path='shop' element={<SuspenseContainer><Shop /></SuspenseContainer>} />
        <Route path='settings' element={<SuspenseContainer><Settings /></SuspenseContainer>} />
        <Route path='widgets' element={<SuspenseContainer><Widgets /></SuspenseContainer>} />
        <Route path='analysis' element={<SuspenseContainer><Analysis /></SuspenseContainer>} />
        <Route path='tables' element={<SuspenseContainer><Tables /></SuspenseContainer>} />
        <Route path='forms' element={<SuspenseContainer><Forms /></SuspenseContainer>} />
        <Route path='icon' element={<SuspenseContainer><Icon /></SuspenseContainer>} />
        <Route path='profile' element={<SuspenseContainer><Profile /></SuspenseContainer>} />
      </Route>
    </Routes>
  )
}

export default RouterMain

