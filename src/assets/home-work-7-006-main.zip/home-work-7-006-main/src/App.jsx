import RouterMain from "./pages"

function App() {
  return <RouterMain/>
}

export default App
