import React from 'react'


const Footer = () => {
  return (
    <div className='min-h-[300px] bg-stone-900 text-white'>
        <p>Footer</p>
    </div>
  )
}

export default Footer