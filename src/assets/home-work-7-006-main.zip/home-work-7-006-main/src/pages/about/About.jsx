import React from 'react'
import { Button } from "antd";
import { Typography } from 'antd';

const { Title } = Typography;

const About = () => {
  return (
    <div className='min-h-screen p-5'>
      <h2>About</h2>
      <Button onClick={()=> alert("mana")}  size='middle'  type="primary">Primary Button</Button>
      <Title level={5}>h2. Ant Design</Title>
    </div>
  )
}

export default About