import React from 'react'

const Table = () => {
  return (
    <div>Table</div>
  )
}

export default Table