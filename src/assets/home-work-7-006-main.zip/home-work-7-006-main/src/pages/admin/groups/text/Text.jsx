import React from 'react'

const Text = () => {
  return (
    <div>
        <h2>Text</h2>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla placeat, magnam temporibus, dolore assumenda saepe tenetur laudantium voluptates amet, totam veniam explicabo voluptate natus aspernatur impedit dolores rerum distinctio laboriosam labore doloremque. Minus provident, quae distinctio excepturi ducimus tenetur necessitatibus impedit laborum fugit illum. Fuga quibusdam dolor officia architecto doloribus odio, debitis minima suscipit facere labore corporis aspernatur deleniti repudiandae. Atque, debitis rem exercitationem labore expedita aliquid, adipisci dolores facere amet voluptate eum consectetur est rerum hic animi sequi fuga! In a quae omnis. Repellendus obcaecati consequatur molestiae, numquam blanditiis iste impedit sequi? Inventore magnam obcaecati consequatur sequi optio tenetur minima necessitatibus blanditiis commodi modi, ea voluptates quos molestiae minus. Veniam asperiores hic itaque accusamus pariatur ratione id unde sed libero, illum fugit quo doloremque officiis repellendus sequi necessitatibus, minima harum officia autem, tempora soluta saepe incidunt! Aliquam iste voluptatibus atque sapiente ullam, ad consequatur corporis fugit perspiciatis ratione. Quasi corporis similique at cumque ratione iure harum eaque corrupti rem et. Veritatis, quaerat rem maxime eaque quia porro autem aliquam facilis sint provident, quidem omnis commodi, labore inventore ab possimus neque quos magnam sequi? Inventore eius laudantium dolor dignissimos ea corrupti similique quos quam suscipit at facere, excepturi tempore. Laborum?</p>
    </div>
  )
}

export default Text