import React from 'react'

const Users = () => {
  return (
    <div>
        <h2 className='text-3xl'>Users</h2>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Officiis unde libero accusantium nemo at corporis dolorum error vero illo commodi. Voluptates aliquam illum autem fuga! Quisquam nisi modi, obcaecati repudiandae totam facilis debitis ad, quis quaerat dolorum incidunt. Similique, labore explicabo sit dolor excepturi tempora adipisci suscipit repellat in molestias ullam velit fuga voluptatibus, cum ipsum omnis repellendus aliquid id? Eligendi incidunt accusantium quaerat, magni sequi ad ipsam facilis illum explicabo voluptatem dolore. Ipsa explicabo officia et quam sint esse unde facilis architecto dolor sit ab modi, nostrum laborum quae repellendus quo! Aspernatur molestias dolor veniam suscipit dignissimos tempore modi!</p>
    </div>
  )
}

export default Users