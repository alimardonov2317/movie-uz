import React from 'react'
import { useGetPruductsQuery } from '../../redux/api/product.api'

const Home = () => {
  const {data} = useGetPruductsQuery({})
  return (
    <div>Home
      <div className='grid grid-cols-5'>
        {
          data?.products?.map((item)=> (
            <div key={item.id}>
              <img src={item.thumbnail} alt="" />
            </div>
          ))
        }
      </div>
    </div>
  )
}

export default Home