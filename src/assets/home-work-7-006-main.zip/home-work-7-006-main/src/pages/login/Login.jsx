import React from "react";
import { useLoginMutation } from "../../redux/api/auth.api";
import { useDispatch } from "react-redux";
import { login } from "../../redux/features/auth.slice";
import { useNavigate } from "react-router-dom";
import { Button, Form, Input } from "antd";
import { Typography } from "antd";

import {  notification } from "antd";

const { Title } = Typography;

const Login = () => {
  const [api, contextHolder] = notification.useNotification();
  const [signin, {isLoading}] = useLoginMutation();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  //   const handleLogin = (event) => {
  //     event.preventDefault();
  //     let formData = new FormData(event.target);
  //     let data = Object.fromEntries(formData);

  //     signin({ ...data, expiresInMins: 10 }) // 10 min
  //       .unwrap()
  //       .then((res) => {
  //         dispatch(login(res.accessToken));
  //         navigate("/admin/groups");
  //       })
  //       .catch((err) => {
  //         alert("xato");
  //       });
  //   };

  const onFinish = (values) => {
    signin({ ...values, expiresInMins: 10 }) // 10 min
      .unwrap()
      .then((res) => {
        dispatch(login(res.accessToken));
        navigate("/admin/groups");
      })
      .catch((err) => {
        api.error({
            message: "Username or password is incorrect",
            placement: "bottomRight"
        })
      });
  };

  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  return (
    <section className="w-full min-h-screen grid place-items-center">
      <div className="border border-gray-400 rounded p-4 max-w-[450px] w-full">
        <Title level={3}>Sign in</Title>
        <Form
          name="basic"
          layout="vertical"
          initialValues={{
            remember: true,
          }}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          autoComplete="off"
        >
          <Form.Item
            label="Username"
            name="username"
            rules={[
              {
                required: true,
                message: "Please input your username!",
              },
            ]}
          >
            <Input placeholder="username" />
          </Form.Item>

          <Form.Item
            label="Parol"
            name="password"
            rules={[
              {
                required: true,
                message: "Please input your password!",
              },
            ]}
          >
            <Input.Password placeholder="password" />
          </Form.Item>


          <Form.Item label={null}>
            <Button loading={isLoading} disabled={isLoading} type="primary" className="w-full" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
          <Form.Item label={null}>
            <Button  onClick={()=> navigate("/")} className="w-full" htmlType="button">
              Go Home
            </Button>
          </Form.Item>
        </Form>
      </div>
      {contextHolder}
    </section>
  );
};

export default Login;
